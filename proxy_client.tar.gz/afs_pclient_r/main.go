package main

import (
	"fmt"
	"os"
	"os/exec"
)

func main() {
	err := readConfig()
	if err != nil {
		return
	}

	err = genProxyConfig()
	if err != nil {
		return
	}

	_, err = runBashComamnd()
	if err != nil {
		return
	}
}

func runBashComamnd() (string, error) {

	var cmd *exec.Cmd
	var commandResult []byte
	var err error

	cmd = exec.Command("./ngrok", "-log=ngrok.log" ,"-config=proxy.yml", "start", "astri")
	dir, err := os.Getwd()
	if err != nil {
		print_debug(DEBUG_MSG_ERROR, "1", err)
	}
	cmd.Dir = dir + "/ngrok/bin/"
	if commandResult, err = cmd.CombinedOutput(); err != nil {
		fmt.Println(fmt.Sprint(err) + ": " + string(commandResult))
		return "", err
	}

	return string(commandResult), nil
}

func genProxyConfig() error {
	f, err := os.Create("./ngrok/bin/proxy.yml")
	if err != nil {
		print_debug(DEBUG_MSG_ERROR, "1", err)
		f.Close()
		return err
	}
	////"tunnels:", "  astri:", "    remote_port: 8082", "    proto:", "      tcp: " + config.BindLocalPort}
	d := []string{"server_addr: " + config.ProxyNodeAddress,
		"tunnels:", "  astri:", "    proto:", "      tcp: " + config.BindLocalPort}
	for _, v := range d {
		fmt.Fprintln(f, v)
		if err != nil {
			print_debug(DEBUG_MSG_ERROR, "2", err)
			return err
		}
	}
	err = f.Close()
	if err != nil {
		print_debug(DEBUG_MSG_ERROR, "3", err)
		return err
	}
	return nil
}
