cat ngrok/bin/public_url.txt
